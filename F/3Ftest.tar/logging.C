#include <logging.h>
#include <stdio.h>
#include <iostream>
#include <fstream>

DataFlowException::DataFlowException(const char *type, const char *error)
{
	sprintf(msg, "Throwing exception: (%s): %s", type, error);
	Logger::LogEvent(msg);
}

FILE *Logger::logger = NULL;

void Logger::LogEvent(const char *event)
{

	Logger::logger = fopen("logger", "w");
	fprintf(logger, "%s\n", event);
}

void Logger::Finalize()
{
	fclose(logger);
}
