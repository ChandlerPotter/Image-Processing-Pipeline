#include <source.h>

Image * Source::GetOutput(void)
{
	return &img;
}